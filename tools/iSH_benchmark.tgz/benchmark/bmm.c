#include <stdio.h>
#include <time.h>

#define ITERATIONS 1000000000

void benchmark_integer() {
    long long sum = 0;
    for (long long i = 0; i < ITERATIONS; ++i) {
        sum += i;
    }
    printf("Integer sum: %lld\n", sum);
}

void benchmark_float() {
    double sum = 0.0;
    for (double i = 0.0; i < ITERATIONS; ++i) {
        sum += i;
    }
    printf("Floating point sum: %f\n", sum);
}

int main() {
    clock_t start, end;
    double cpu_time_used;

    start = clock();
    benchmark_integer();
    end = clock();
    cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
    printf("Integer benchmark completed in %f seconds\n", cpu_time_used);

    start = clock();
    benchmark_float();
    end = clock();
    cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
    printf("Floating point benchmark completed in %f seconds\n", cpu_time_used);

    return 0;
}

